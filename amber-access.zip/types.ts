
export interface AppState {
  revealed: boolean;
}
